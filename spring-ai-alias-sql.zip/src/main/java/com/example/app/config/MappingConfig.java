package com.example.app.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.app.util.SQLAliasResolver.Mapping;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.InputStream;
import java.util.Map;

@Configuration
public class MappingConfig {

    @Bean
    public Map<String, Mapping> schemaMapping(ObjectMapper mapper) throws Exception {
        InputStream is = getClass().getClassLoader().getResourceAsStream("schema-mapping.json");
        return mapper.readValue(is,
            mapper.getTypeFactory().constructMapType(Map.class, String.class, Mapping.class));
    }
}
