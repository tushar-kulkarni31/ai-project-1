package com.example.app.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

@Service
public class EmbeddingService {

    private final WebClient client = WebClient.create();

    public List<List<Double>> embedTexts(List<String> texts) {
        Map<String, Object> request = Map.of("model", "nomic-embed-text", "prompt", texts);
        Map<String, Object> response = client.post()
            .uri("http://localhost:11434/api/embeddings")
            .bodyValue(request)
            .retrieve().bodyToMono(Map.class).block();
        return (List<List<Double>>) response.get("embeddings");
    }
}
