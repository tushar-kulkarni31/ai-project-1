package com.example.app.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class SqlGenerationService {

    private final WebClient client = WebClient.create();
    @Value("classpath:schema-prompt.txt")
    private org.springframework.core.io.Resource promptResource;

    public String generateAliasedSql(String userQuery) throws Exception {
        String basePrompt = Files.readString(Paths.get(promptResource.getURI()));
        String fullPrompt = basePrompt + "\n" + userQuery;
        // Call Ollama to generate SQL
        String response = client.post()
            .uri("http://localhost:11434/api/generate")
            .bodyValue(Map.of("model", "llama3", "prompt", fullPrompt))
            .retrieve()
            .bodyToMono(String.class)
            .block();
        return response.trim();
    }
}
