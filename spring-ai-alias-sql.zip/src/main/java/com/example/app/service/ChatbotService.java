package com.example.app.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

@Service
public class ChatbotService {

    private final WebClient client = WebClient.create();

    public String askWithContext(String userQuery, List<String> contextRows) {
        String context = String.join("\n", contextRows);
        Map<String, Object> request = Map.of(
            "model", "llama3",
            "prompt", "User Query: " + userQuery + "\nContext:\n" + context
        );
        Map<String, Object> response = client.post()
            .uri("http://localhost:11434/api/generate")
            .bodyValue(request)
            .retrieve().bodyToMono(Map.class).block();
        return response.get("text").toString();
    }
}
