package com.example.app.service;

import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Service
public class OracleService {

    public List<String> executeQuery(String sql) throws Exception {
        List<String> rows = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE", "your_user", "your_password");
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            int cols = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                StringBuilder sb = new StringBuilder();
                for (int i = 1; i <= cols; i++) {
                    sb.append(rs.getMetaData().getColumnName(i))
                      .append(": ").append(rs.getString(i)).append("; ");
                }
                rows.add(sb.toString());
            }
        }
        return rows;
    }
}
