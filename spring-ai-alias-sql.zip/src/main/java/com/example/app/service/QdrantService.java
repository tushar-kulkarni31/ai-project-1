package com.example.app.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class QdrantService {

    private final WebClient client = WebClient.create("http://localhost:6333");

    public void storeVectors(List<String> rows, List<List<Double>> vectors) {
        List<Map<String, Object>> points = IntStream.range(0, rows.size())
            .mapToObj(i -> Map.of(
                "id", UUID.randomUUID().toString(),
                "vector", vectors.get(i),
                "payload", Map.of("text", rows.get(i))
            )).collect(Collectors.toList());

        Map<String, Object> payload = Map.of("points", points);
        client.put()
            .uri("/collections/alias_data/points")
            .bodyValue(payload)
            .retrieve().bodyToMono(String.class).block();
    }
}
