package com.example.app.util;

import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.Select;
import net.sf.jsqlparser.util.deparser.StatementDeParser;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class SQLAliasResolver {

    public static class Mapping {
        public String realTable;
        public Map<String, String> columns;
    }

    private final Map<String, Mapping> schemaMapping;

    public SQLAliasResolver(Map<String, Mapping> schemaMapping) {
        this.schemaMapping = schemaMapping;
    }

    public String resolveAliasedSql(String aliasedSql) throws Exception {
        Statement stmt = CCJSqlParserUtil.parse(aliasedSql);
        StringBuilder buffer = new StringBuilder();
        StatementDeParser deParser = new StatementDeParser(buffer) {
            @Override
            public void visit(net.sf.jsqlparser.schema.Table table) {
                String name = table.getName();
                Mapping m = schemaMapping.get(name);
                if (m != null) {
                    table.setName(m.realTable);
                }
                super.visit(table);
            }

            @Override
            public void visit(net.sf.jsqlparser.schema.Column column) {
                String col = column.getColumnName();
                // find mapping
                schemaMapping.forEach((alias, mapping) -> {
                    if (mapping.columns.containsKey(col)) {
                        column.setColumnName(mapping.columns.get(col));
                        if (column.getTable() != null && alias.equals(column.getTable().getName())) {
                            column.getTable().setName(mapping.realTable);
                        }
                    }
                });
                super.visit(column);
            }
        };
        ((Select) stmt).getSelectBody().accept(deParser);
        return buffer.toString();
    }
}
