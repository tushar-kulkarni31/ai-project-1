package com.example.app.controller;

import com.example.app.service.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chat")
public class ChatController {

    private final SqlGenerationService sqlGen;
    private final SQLAliasResolver aliasResolver;
    private final OracleService oracleService;
    private final EmbeddingService embedSvc;
    private final QdrantService qdrantSvc;
    private final ChatbotService chatSvc;

    public ChatController(SqlGenerationService sqlGen,
                          SQLAliasResolver aliasResolver,
                          OracleService oracleService,
                          EmbeddingService embedSvc,
                          QdrantService qdrantSvc,
                          ChatbotService chatSvc) {
        this.sqlGen = sqlGen;
        this.aliasResolver = aliasResolver;
        this.oracleService = oracleService;
        this.embedSvc = embedSvc;
        this.qdrantSvc = qdrantSvc;
        this.chatSvc = chatSvc;
    }

    @PostMapping("/ask")
    public ResponseEntity<String> ask(@RequestBody Map<String, String> payload) throws Exception {
        String userQuery = payload.get("query");
        // 1. Generate aliased SQL
        String aliasedSql = sqlGen.generateAliasedSql(userQuery);
        // 2. Resolve to real SQL
        String realSql = aliasResolver.resolveAliasedSql(aliasedSql);
        // 3. Execute on Oracle
        List<String> rows = oracleService.executeQuery(realSql);
        // 4. Embed rows and store in Qdrant
        List<List<Double>> vectors = embedSvc.embedTexts(rows);
        qdrantSvc.storeVectors(rows, vectors);
        // 5. Generate final chat response
        String answer = chatSvc.askWithContext(userQuery, rows);
        return ResponseEntity.ok(answer);
    }
}
